package sample;


import javafx.application.Platform;

import static javafx.application.Application.launch;

public class Main {

    public static void main(String[] args) {
        launch(GUI.class);
    }
}
