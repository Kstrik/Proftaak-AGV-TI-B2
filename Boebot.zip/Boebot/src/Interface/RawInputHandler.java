package Interface;

public class RawInputHandler {
}