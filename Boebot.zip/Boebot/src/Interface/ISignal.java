package Interface;

public interface ISignal {

	Command convertToCommand();

}