package Interface;

public class WifiSignal {
}