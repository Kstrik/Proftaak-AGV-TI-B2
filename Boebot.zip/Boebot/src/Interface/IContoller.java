package Interface;

public interface IContoller {

	void onCommandReceived(Command command);

	void update();
}