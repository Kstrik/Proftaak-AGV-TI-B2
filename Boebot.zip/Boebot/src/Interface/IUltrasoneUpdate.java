package Interface;

public interface IUltrasoneUpdate {

    void onUltrasoneUpdate(int pulse);

}
