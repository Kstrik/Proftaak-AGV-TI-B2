package Interface;

public class XMLReader {
}