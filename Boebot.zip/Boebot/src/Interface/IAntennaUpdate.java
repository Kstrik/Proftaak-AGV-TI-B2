package Interface;

import Hardware.Antenna;

public interface IAntennaUpdate {

    void onAntennaUpdate(boolean hit, Antenna antenna);

}
