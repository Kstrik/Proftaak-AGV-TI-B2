package Hardware;

public interface ISensor {

	void update();
}