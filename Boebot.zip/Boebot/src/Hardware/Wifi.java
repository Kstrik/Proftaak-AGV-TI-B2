package Hardware;

public class Wifi {
}