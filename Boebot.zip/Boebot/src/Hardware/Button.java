package Hardware;

public class Button {
}