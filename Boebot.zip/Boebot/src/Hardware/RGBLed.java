package Hardware;

public class RGBLed {
}